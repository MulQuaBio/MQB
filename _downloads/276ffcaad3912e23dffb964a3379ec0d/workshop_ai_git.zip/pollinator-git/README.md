# Pollinator Git practice

Open task.html for the exercise. This folder already contains a local
Git repository with one commit and two changes to review. Start with
git status from this folder. Leave it separate from your other projects.
