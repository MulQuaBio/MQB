raise NotImplementedError("Scaffold: add integration checks against protected expectations")
