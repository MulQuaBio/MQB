set -euo pipefail
printf "Scaffold: pipeline not connected\n" >&2
exit 2
