stop("Scaffold: connect a validated summary to a labelled figure")
