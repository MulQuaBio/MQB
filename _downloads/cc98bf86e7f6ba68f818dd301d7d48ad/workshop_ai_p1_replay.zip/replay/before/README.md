# Integration practice

This scaffold is not yet a working pipeline.
