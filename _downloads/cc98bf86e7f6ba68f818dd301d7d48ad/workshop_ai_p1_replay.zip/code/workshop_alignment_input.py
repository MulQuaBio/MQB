import csv
from pathlib import Path
import sys
from workshop_alignment_ties import main as align
if len(sys.argv) != 3:
    raise ValueError("Supply one-pair CSV input and output path")
with Path(sys.argv[1]).open(newline="", encoding="utf-8") as stream:
    reader = csv.DictReader(stream)
    if reader.fieldnames != ["sequence_a", "sequence_b"]:
        raise ValueError("Wrong alignment input schema")
    rows = list(reader)
if len(rows) != 1:
    raise ValueError("This adapter expects exactly one sequence pair")
align([rows[0]["sequence_a"], rows[0]["sequence_b"], sys.argv[2]])
