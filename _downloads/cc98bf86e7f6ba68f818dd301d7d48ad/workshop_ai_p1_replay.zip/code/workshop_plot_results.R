args <- commandArgs(trailingOnly=TRUE)
if (length(args) != 3L) stop("Supply summary CSV, figure SVG and track")
input <- args[[1]]; output <- args[[2]]; track <- args[[3]]
x <- read.csv(input, check.names=FALSE, stringsAsFactors=FALSE, colClasses="character")
if (track == "tree") {
    expected <- c("location", "total_rows", "rejected_rows", "rejection_fraction", "flagged", "top_reasons")
    if (!identical(names(x), expected)) stop("Tree summary schema mismatch")
    total <- as.numeric(x$total_rows); rejected <- as.numeric(x$rejected_rows)
    values <- as.numeric(x$rejection_fraction)
    if (any(!is.finite(c(total, rejected, values))) || any(total <= 0) ||
        any(total != floor(total) | rejected != floor(rejected)) ||
        any(rejected < 0 | rejected > total) || any(abs(values-rejected/total) > 1e-10))
        stop("Invalid tree summary values")
    flag <- values > 0.5
    if (any(x$flagged != ifelse(flag, "true", "false"))) stop("Flag boundary mismatch")
    labels <- x$location
    colours <- ifelse(flag, "#b2182b", "#2166ac")
    title <- "Tree-survey rejections"; ylabel <- "Rejected fraction"
} else if (track == "alignment") {
    if (!identical(names(x), c("start_position", "score", "alignment"))) stop("Alignment schema mismatch")
    starts <- as.numeric(x$start_position); values <- as.numeric(x$score)
    if (any(!is.finite(c(starts, values))) || any(starts < 0 | starts != floor(starts)) ||
        any(values < 0 | values != floor(values)) || anyDuplicated(starts) ||
        is.unsorted(starts) || length(unique(values)) > 1L) stop("Invalid tied-alignment values")
    labels <- paste("start", x$start_position)
    colours <- rep("#2166ac", nrow(x))
    title <- "All best alignment starts"; ylabel <- "Match score (bases)"
} else if (track == "population") {
    expected <- c("series_id", "model", "population", "label", "window", "extinction_threshold",
                  "equilibrium_tolerance", "min_points", "period", "last_value", "tail_range", "period_residual")
    if (!identical(names(x), expected)) stop("Population summary schema mismatch")
    values <- as.numeric(x$last_value)
    if (any(!is.finite(values)) || any(values < 0) ||
        any(!x$label %in% c("apparent_extinction", "near_equilibrium", "repeated_oscillation", "indeterminate")))
        stop("Invalid population summary")
    labels <- paste(x$series_id, x$population, x$label, sep=" / ")
    colours <- rep("#2166ac", nrow(x))
    title <- "Finite-window population classification"; ylabel <- "Last population value (model units)"
} else stop("Unknown track")
dir.create(dirname(output), showWarnings=FALSE, recursive=TRUE)
svg(output, width=9, height=if (track == "population") 8 else 5)
par(mar=if (track == "population") c(16, 5, 3, 1) else c(5, 5, 3, 1))
if (length(values)) {
    limit <- if (track == "tree") 1 else max(1, max(values)*1.1)
    barplot(values, names.arg=labels, col=colours, las=if (track == "population") 2 else 1, cex.names=0.9,
            ylim=c(0, limit), main=title, ylab=ylabel)
    if (track == "tree") abline(h=0.5, lty=2)
} else {
    plot.new(); title(main=title); text(0.5, 0.5, "No records")
}
invisible(dev.off())
xml_escape <- function(s) {
    s <- gsub("&", "&amp;", s, fixed=TRUE)
    s <- gsub("<", "&lt;", s, fixed=TRUE)
    gsub(">", "&gt;", s, fixed=TRUE)
}
description <- xml_escape(paste(c(ylabel, labels), collapse="; "))
picture <- paste(readLines(output, warn=FALSE), collapse="\n")
picture <- sub("(<svg[^>]*>)", paste0("\\1<title>", xml_escape(title), "</title><desc>",
                 description, "</desc>"), picture, perl=TRUE)
writeLines(picture, output)
cat("Validated", track, "CSV; wrote labelled SVG\n")
