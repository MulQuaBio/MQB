import csv
from pathlib import Path
import sys

def best_alignments(first, second):
    for sequence in (first, second):
        if not isinstance(sequence, str) or not sequence or set(sequence) - set("ACGT"):
            raise ValueError("Require non-empty uppercase A/C/G/T strings")
    longer, shorter = (first, second) if len(first) >= len(second) else (second, first)
    best_score = -1
    best_rows = []
    for start in range(len(longer)):
        score = sum(longer[start+i] == base
                    for i, base in enumerate(shorter) if start+i < len(longer))
        row = {"start_position": start, "score": score, "alignment": "."*start + shorter}
        if score > best_score:
            best_score = score
            best_rows = [row]
        elif score == best_score:
            best_rows.append(row)
    return best_rows

def main(argv):
    if len(argv) != 3:
        raise ValueError("Supply two sequences and an output CSV path")
    rows = best_alignments(argv[0], argv[1])
    target = Path(argv[2])
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=["start_position", "score", "alignment"])
        writer.writeheader()
        writer.writerows(rows)

if __name__ == "__main__":
    main(sys.argv[1:])
