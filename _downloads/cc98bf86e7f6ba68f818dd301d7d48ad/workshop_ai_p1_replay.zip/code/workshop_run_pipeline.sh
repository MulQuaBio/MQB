set -euo pipefail
if [ "$#" -ne 3 ]; then
    printf "Usage: bash code/workshop_run_pipeline.sh track input.csv fresh-output-dir\n" >&2
    exit 2
fi
track=$1
input=$2
output=$3
python_exe=${MQB_PYTHON:-python3}
if [ ! -d code ] || [ ! -f "$input" ]; then
    printf "Run from the project root with an existing input CSV\n" >&2
    exit 2
fi
if [ -e "$output" ]; then
    printf "Choose a fresh output directory; existing output is not a new successful run\n" >&2
    exit 2
fi
mkdir -p "$output"
case "$track" in
    tree) "$python_exe" code/workshop_tree_quality.py "$input" "$output/summary.csv" ;;
    alignment) "$python_exe" code/workshop_alignment_input.py "$input" "$output/summary.csv" ;;
    population) "$python_exe" code/workshop_population_regimes.py "$input" "$output/summary.csv" ;;
    *) printf "Unknown track\n" >&2; exit 2 ;;
esac
Rscript code/workshop_plot_results.R "$output/summary.csv" "$output/figure.svg" "$track"
printf "Producer and plotter completed\n" > "$output/SUCCESS"
printf "Completed a fresh %s run\n" "$track"
