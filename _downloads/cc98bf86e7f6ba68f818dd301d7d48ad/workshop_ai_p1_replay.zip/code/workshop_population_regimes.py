import csv
import math
from pathlib import Path
import sys

FIELDS = ["series_id", "model", "population", "label", "window", "extinction_threshold",
          "equilibrium_tolerance", "min_points", "period", "last_value", "tail_range", "period_residual"]

def classify(values, window=12, extinction_threshold=0.5, equilibrium_tolerance=0.05):
    if not isinstance(window, int) or isinstance(window, bool) or window < 6:
        raise ValueError("window must be an integer >= 6")
    if not math.isfinite(extinction_threshold) or extinction_threshold < 0:
        raise ValueError("Invalid extinction threshold")
    if not math.isfinite(equilibrium_tolerance) or equilibrium_tolerance < 0:
        raise ValueError("Invalid equilibrium tolerance")
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) or x < 0 for x in values):
        raise ValueError("Population values must be finite and non-negative")
    tail = values[-window:]
    result = dict(label="indeterminate", window=window, extinction_threshold=extinction_threshold,
                  equilibrium_tolerance=equilibrium_tolerance, min_points=window, period="",
                  last_value=values[-1] if values else "", tail_range=max(tail)-min(tail) if tail else "",
                  period_residual="")
    if len(values) < window:
        return result
    scale = max(sum(tail)/len(tail), extinction_threshold, 1e-12)
    if max(tail) <= extinction_threshold:
        result["label"] = "apparent_extinction"
    elif (max(tail)-min(tail))/scale <= equilibrium_tolerance:
        result["label"] = "near_equilibrium"
    else:
        for period in range(2, 5):
            if len(tail) < 3*period:
                continue
            residual = max(abs(tail[i]-tail[i-period]) for i in range(period, len(tail))) / scale
            if residual <= equilibrium_tolerance:
                result.update(label="repeated_oscillation", period=period, period_residual=residual)
                break
    return result

def main(argv):
    if len(argv) != 2:
        raise ValueError("Supply trace CSV and output CSV")
    groups = {}
    with Path(argv[0]).open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != ["series_id", "model", "population", "time", "value"]:
            raise ValueError("Wrong trace schema")
        for row in reader:
            key = (row["series_id"], row["model"], row["population"])
            if not all(key):
                raise ValueError("Series metadata must be non-empty")
            time = float(row["time"])
            if not math.isfinite(time) or (key in groups and time <= groups[key][-1][0]):
                raise ValueError("Times must increase within a series")
            groups.setdefault(key, []).append((time, float(row["value"])))
    target = Path(argv[1])
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        for (series_id, model, population), records in sorted(groups.items()):
            writer.writerow(dict(series_id=series_id, model=model, population=population,
                                 **classify([value for _, value in records])))

if __name__ == "__main__":
    main(sys.argv[1:])
