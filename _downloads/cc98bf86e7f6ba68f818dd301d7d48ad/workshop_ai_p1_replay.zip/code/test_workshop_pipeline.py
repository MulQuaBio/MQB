import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
(ROOT / "results").mkdir(exist_ok=True)
SCRATCH = Path(tempfile.mkdtemp(prefix="workshop-checks-", dir=ROOT / "results"))

def invoke(command, ok=True, extra_env=None):
    env = os.environ.copy()
    env["MQB_PYTHON"] = sys.executable
    if extra_env:
        env.update(extra_env)
    result = subprocess.run([str(x) for x in command], cwd=ROOT, env=env,
                            text=True, capture_output=True, timeout=40)
    if (result.returncode == 0) != ok:
        raise AssertionError(result.stdout + result.stderr)
    return result

def load_rows(path):
    with Path(path).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))

data_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
               for p in (ROOT / "data").iterdir() if p.is_file()}
expected = json.loads((ROOT / "data/workshop_expected_quality.json").read_text())
first = SCRATCH / "tree_first"
second = SCRATCH / "tree_second"
for target in (first, second):
    invoke(["bash", "code/workshop_run_pipeline.sh", "tree", "data/workshop_tree_outcomes.csv", target])
    assert (target / "SUCCESS").is_file()
rows = load_rows(first / "summary.csv")
assert [row["location"] for row in rows] == sorted(expected)
for row in rows:
    wanted = expected[row["location"]]
    assert math.isclose(float(row["rejection_fraction"]), wanted["fraction"])
    assert row["flagged"] == wanted["flagged"]
    assert row["top_reasons"] == wanted["top_reasons"]
assert (first / "summary.csv").read_bytes() == (second / "summary.csv").read_bytes()
picture = ET.parse(first / "figure.svg").getroot()
namespace = "{http://www.w3.org/2000/svg}"
assert picture.find(namespace + "title").text == "Tree-survey rejections"
description = picture.find(namespace + "desc").text
assert "Rejected fraction" in description and all(name in description for name in expected)
invoke(["bash", "code/workshop_run_pipeline.sh", "tree", "data/workshop_tree_outcomes.csv", first], ok=False)

missing = SCRATCH / "missing"
invoke(["bash", "code/workshop_run_pipeline.sh", "tree", "data/absent.csv", missing], ok=False)
assert not (missing / "SUCCESS").exists()
fake_python = SCRATCH / "workshop_fail_producer.sh"
fake_python.write_text("#!/bin/sh\nexit 7\n")
fake_python.chmod(0o700)
failed = SCRATCH / "failed_producer"
invoke(["bash", "code/workshop_run_pipeline.sh", "tree", "data/workshop_tree_outcomes.csv", failed],
       ok=False, extra_env={"MQB_PYTHON": str(fake_python)})
assert not (failed / "SUCCESS").exists() and not (failed / "figure.svg").exists()

mismatch = SCRATCH / "wrong_columns.csv"
mismatch.write_text((first / "summary.csv").read_text().replace("rejection_fraction", "fraction_wrong", 1))
bad_figure = SCRATCH / "wrong_columns.svg"
invoke(["Rscript", "code/workshop_plot_results.R", mismatch, bad_figure, "tree"], ok=False)
assert not bad_figure.exists()

alignment = SCRATCH / "alignment"
invoke(["bash", "code/workshop_run_pipeline.sh", "alignment", "data/workshop_alignment_input.csv", alignment])
alignment_rows = load_rows(alignment / "summary.csv")
assert [int(row["start_position"]) for row in alignment_rows] == [0, 1, 2]
assert [int(row["score"]) for row in alignment_rows] == [2, 2, 2]
for family, known_series, population in [
    ("ricker", "ricker_equilibrium", "N"), ("lv", "lv_equilibrium", "resource_prey")
]:
    destination = SCRATCH / family
    invoke(["bash", "code/workshop_run_pipeline.sh", "population",
            "data/workshop_" + family + "_traces.csv", destination])
    records = load_rows(destination / "summary.csv")
    known = next(row for row in records if row["series_id"] == known_series)
    assert known["label"] == "near_equilibrium" and known["population"] == population
    assert (destination / "SUCCESS").is_file()
assert data_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in (ROOT / "data").iterdir() if p.is_file()}
print("Pipeline checks passed: hand expectations, fresh/repeat runs, immutable inputs,")
print("missing input, failed producer, wrong CSV columns, alignment and both population adapters.")
