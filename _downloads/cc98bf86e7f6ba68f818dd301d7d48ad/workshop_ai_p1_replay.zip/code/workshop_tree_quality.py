from collections import Counter, defaultdict
import csv
from pathlib import Path
import sys

INPUT_FIELDS = ["source_row", "location", "status", "reasons"]
OUTPUT_FIELDS = ["location", "total_rows", "rejected_rows", "rejection_fraction", "flagged", "top_reasons"]

def summarise_quality(rows):
    groups = defaultdict(list)
    seen = set()
    for row in rows:
        if set(row) != set(INPUT_FIELDS) or any(not isinstance(row[k], str) for k in INPUT_FIELDS):
            raise ValueError("Wrong outcome row schema")
        identifier = row["source_row"]
        if not identifier.isdigit() or int(identifier) < 1 or int(identifier) in seen:
            raise ValueError("source_row must be a unique positive integer")
        seen.add(int(identifier))
        location = row["location"]
        if not location or location != location.strip():
            raise ValueError("Use canonical non-empty location labels")
        reasons = {reason.strip() for reason in row["reasons"].split(";") if reason.strip()}
        status = row["status"]
        if status not in {"accepted", "rejected"}:
            raise ValueError("Unknown status")
        if (status == "accepted" and reasons) or (status == "rejected" and not reasons):
            raise ValueError("Reasons do not match status")
        groups[location].append((status, reasons))
    output = []
    for location in sorted(groups):
        records = groups[location]
        rejected = sum(status == "rejected" for status, _ in records)
        counts = Counter(reason for status, reasons in records if status == "rejected" for reason in reasons)
        top = sorted(reason for reason, n in counts.items() if n == max(counts.values())) if counts else []
        fraction = rejected / len(records)
        output.append(dict(location=location, total_rows=len(records), rejected_rows=rejected,
                           rejection_fraction=fraction, flagged=fraction > 0.5, top_reasons="; ".join(top)))
    return output

def main(argv):
    if len(argv) != 2:
        raise ValueError("Supply outcome input CSV and output CSV")
    with Path(argv[0]).open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != INPUT_FIELDS:
            raise ValueError("Wrong outcome CSV header")
        rows = summarise_quality(list(reader))
    target = Path(argv[1])
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        for row in rows:
            writer.writerow({**row, "flagged": str(row["flagged"]).lower()})

if __name__ == "__main__":
    main(sys.argv[1:])
