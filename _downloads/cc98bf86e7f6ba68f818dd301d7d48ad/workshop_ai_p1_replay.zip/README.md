# Checked capstone integration

Run from this project root. Requirements: Python 3, Bash and base R with Rscript.
No package installation, network service or AI account is needed for the replay.
MQB_PYTHON can select the Python executable; otherwise the runner uses python3.

Single run command, with a fresh output directory:
    bash code/workshop_run_pipeline.sh tree data/workshop_tree_outcomes.csv results/my_tree_run

Other prepared routes:
    bash code/workshop_run_pipeline.sh alignment data/workshop_alignment_input.csv results/my_alignment_run
    bash code/workshop_run_pipeline.sh population data/workshop_ricker_traces.csv results/my_ricker_run
    bash code/workshop_run_pipeline.sh population data/workshop_lv_traces.csv results/my_lv_run

Each output contains summary.csv, figure.svg and a SUCCESS marker written only
after both stages complete. Existing output directories are rejected, not treated
as a successful new run. Inspect the exit status: old files are not new evidence.

Tree schema: location,total_rows,rejected_rows,rejection_fraction,flagged,top_reasons.
The denominator is all rows at the location; flagged means strictly more than half.
Fractions are unitless, flags are lowercase true/false, locations are sorted,
and all tied leading reasons are joined with semicolon-space.
Hand expectation: Silwood 2/3 flagged; Nash's 1/2 not flagged; Reactor 0/1 not flagged.

Alignment schema: start_position,score,alignment; zero-based starts, ascending,
all ties retained, score in matching bases. Population summaries retain model,
selected population, operational label, window, thresholds and measurements.
A population label is evidence from a finite window, not proof of long-term dynamics.

Independent checks:
    python3 code/test_workshop_pipeline.py

Do not change protected producers, source data or expected-result fixtures.
Review the actual R figure as well as the CSV and tests. Record your own
specification, extra test, accepted/rejected change and final explanation.

Prepared integration candidate: AI-assisted Codex authoring, 22 October 2026.
The replay folder contains before/after files, a unified diff and the actual
execution log generated when the notebook runs. This is not a live Copilot UI log.
If using the replay, record that you reviewed prepared changes rather than
claiming to have conducted a live agent session. No commit/push is part of the task.
